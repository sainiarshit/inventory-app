/* eslint-ignore */
module.exports = require('./dist/babel').test()


// `victory-vendor/d3-time` (TypeScript)
//
// Export the type definitions for this package:
export * from "d3-time";

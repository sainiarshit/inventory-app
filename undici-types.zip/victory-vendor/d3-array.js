
// `victory-vendor/d3-array` (CommonJS)
// See upstream license: https://github.com/d3/d3-array/blob/main/LICENSE
//
// This file only exists for tooling that doesn't work yet with package.json:exports
// by proxying through the CommonJS version.
module.exports = require("./lib/d3-array");

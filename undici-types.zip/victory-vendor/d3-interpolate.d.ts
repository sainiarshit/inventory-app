
// `victory-vendor/d3-interpolate` (TypeScript)
//
// Export the type definitions for this package:
export * from "d3-interpolate";

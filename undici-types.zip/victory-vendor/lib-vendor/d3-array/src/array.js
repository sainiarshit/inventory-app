"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.slice = exports.map = void 0;
var array = Array.prototype;
var slice = exports.slice = array.slice;
var map = exports.map = array.map;
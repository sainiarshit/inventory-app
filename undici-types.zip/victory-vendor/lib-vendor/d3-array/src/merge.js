"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = merge;
function* flatten(arrays) {
  for (const array of arrays) {
    yield* array;
  }
}
function merge(arrays) {
  return Array.from(flatten(arrays));
}
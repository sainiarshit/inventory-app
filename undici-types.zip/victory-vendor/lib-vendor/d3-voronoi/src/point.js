"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.x = x;
exports.y = y;
function x(d) {
  return d[0];
}
function y(d) {
  return d[1];
}
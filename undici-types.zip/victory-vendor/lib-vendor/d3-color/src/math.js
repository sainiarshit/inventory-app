"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.radians = exports.degrees = void 0;
const radians = exports.radians = Math.PI / 180;
const degrees = exports.degrees = 180 / Math.PI;
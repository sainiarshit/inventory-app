# `react-label`

## Installation

```sh
$ yarn add @radix-ui/react-label
# or
$ npm install @radix-ui/react-label
```

## Usage

View docs [here](https://radix-ui.com/primitives/docs/utilities/label).

# `react-toast`

## Installation

```sh
$ yarn add @radix-ui/react-toast
# or
$ npm install @radix-ui/react-toast
```

## Usage

View docs [here](https://radix-ui.com/primitives/docs/components/toast).

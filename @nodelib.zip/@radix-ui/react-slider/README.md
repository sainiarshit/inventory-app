# `react-slider`

## Installation

```sh
$ yarn add @radix-ui/react-slider
# or
$ npm install @radix-ui/react-slider
```

## Usage

View docs [here](https://radix-ui.com/primitives/docs/components/slider).

# `react-hover-card`

## Installation

```sh
$ yarn add @radix-ui/react-hover-card
# or
$ npm install @radix-ui/react-hover-card
```

## Usage

View docs [here](https://radix-ui.com/primitives/docs/components/hover-card).

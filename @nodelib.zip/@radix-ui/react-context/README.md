# `react-context`

## Installation

```sh
$ yarn add @radix-ui/react-context
# or
$ npm install @radix-ui/react-context
```

## Usage

This is an internal utility, not intended for public usage.

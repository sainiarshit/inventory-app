# `react-focus-guards`

## Installation

```sh
$ yarn add @radix-ui/react-focus-guards
# or
$ npm install @radix-ui/react-focus-guards
```

## Usage

This is an internal utility, not intended for public usage.

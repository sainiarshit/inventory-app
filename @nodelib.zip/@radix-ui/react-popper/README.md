# `react-popper`

## Installation

```sh
$ yarn add @radix-ui/react-popper
# or
$ npm install @radix-ui/react-popper
```

## Usage

This is an internal utility, not intended for public usage.

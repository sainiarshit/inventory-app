# `rect`

## Installation

```sh
$ yarn add @radix-ui/rect
# or
$ npm install @radix-ui/rect
```

## Usage

This is an internal utility, not intended for public usage.

# `react-compose-refs`

## Installation

```sh
$ yarn add @radix-ui/react-compose-refs
# or
$ npm install @radix-ui/react-compose-refs
```

## Usage

This is an internal utility, not intended for public usage.

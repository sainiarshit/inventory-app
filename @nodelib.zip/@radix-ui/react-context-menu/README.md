# `react-context-menu`

## Installation

```sh
$ yarn add @radix-ui/react-context-menu
# or
$ npm install @radix-ui/react-context-menu
```

## Usage

View docs [here](https://radix-ui.com/primitives/docs/components/context-menu).

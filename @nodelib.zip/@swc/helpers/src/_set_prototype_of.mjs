export { _ as default } from "../esm/_set_prototype_of.js";

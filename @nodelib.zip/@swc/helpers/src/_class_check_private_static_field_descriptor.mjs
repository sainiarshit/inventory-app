export { _ as default } from "../esm/_class_check_private_static_field_descriptor.js";

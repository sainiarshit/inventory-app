export { _ as default } from "../esm/_identity.js";

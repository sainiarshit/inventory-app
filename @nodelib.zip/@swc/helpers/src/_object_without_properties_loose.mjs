export { _ as default } from "../esm/_object_without_properties_loose.js";

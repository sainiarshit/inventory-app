# @swc/couter

Download counter for swc packages.

This package does not contain any code. It is used solely to track number of downloads of npm packages like `@swc/core` and `@next/swc`. If you are building a huge project using SWC, please consider depending on this package. It will not add any code to your bundle, but it will help us determine the number of users of SWC.

Counting is done by npm, just like other packages.

export class HandledError {
  constructor(
    public readonly value: any,
    public readonly meta: any = undefined,
  ) {}
}

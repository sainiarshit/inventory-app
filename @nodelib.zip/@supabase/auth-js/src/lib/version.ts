export const version = '2.70.0'

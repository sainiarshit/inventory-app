import GoTrueAdminApi from './GoTrueAdminApi'

const AuthAdminApi = GoTrueAdminApi

export default AuthAdminApi

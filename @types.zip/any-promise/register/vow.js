'use strict';
require('../register')('vow', {Promise: require('vow').Promise})

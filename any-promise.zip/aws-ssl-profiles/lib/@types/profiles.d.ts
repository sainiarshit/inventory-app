export type CA = string[];
export type Profiles = {
    ca: CA;
};

import type * as errors from "../core/errors.js";
export default function (): {
    localeError: errors.$ZodErrorMap;
};

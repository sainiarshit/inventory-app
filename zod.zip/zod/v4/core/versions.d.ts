export declare const version: {
    readonly major: 4;
    readonly minor: 0;
    readonly patch: number;
};

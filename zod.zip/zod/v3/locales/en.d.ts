import { type ZodErrorMap } from "../ZodError.js";
declare const errorMap: ZodErrorMap;
export default errorMap;

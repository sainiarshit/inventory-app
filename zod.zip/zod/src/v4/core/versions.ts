export const version = {
  major: 4,
  minor: 0,
  patch: 0 as number,
} as const;

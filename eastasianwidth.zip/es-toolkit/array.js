module.exports = require('./dist/array');

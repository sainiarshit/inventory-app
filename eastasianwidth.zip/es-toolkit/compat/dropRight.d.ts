export { dropRight as default } from '../dist/compat/array/dropRight.js';

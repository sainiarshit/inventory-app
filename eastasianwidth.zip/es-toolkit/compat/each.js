module.exports = require('../dist/compat/array/forEach.js').forEach;

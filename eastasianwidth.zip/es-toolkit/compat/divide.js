module.exports = require('../dist/compat/math/divide.js').divide;

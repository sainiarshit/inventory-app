module.exports = require('../dist/compat/object/defaults.js').defaults;

module.exports = require('../dist/compat/predicate/isObjectLike.js').isObjectLike;

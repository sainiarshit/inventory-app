export { findIndex as default } from '../dist/compat/array/findIndex.js';

module.exports = require('../dist/compat/predicate/isElement.js').isElement;

module.exports = require('../dist/predicate/isEqual.js').isEqual;

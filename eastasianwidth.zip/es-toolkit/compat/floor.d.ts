export { floor as default } from '../dist/compat/math/floor.js';

module.exports = require('../dist/compat/array/head.js').head;

export { intersection as default } from '../dist/compat/array/intersection.js';

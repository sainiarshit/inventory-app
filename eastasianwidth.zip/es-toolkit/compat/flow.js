module.exports = require('../dist/compat/function/flow.js').flow;

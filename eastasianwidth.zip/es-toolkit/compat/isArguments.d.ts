export { isArguments as default } from '../dist/compat/predicate/isArguments.js';

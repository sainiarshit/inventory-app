export { ary as default } from '../dist/compat/function/ary.js';

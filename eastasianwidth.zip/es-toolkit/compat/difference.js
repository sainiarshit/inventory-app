module.exports = require('../dist/compat/array/difference.js').difference;

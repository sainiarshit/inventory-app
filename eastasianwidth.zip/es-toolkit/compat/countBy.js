module.exports = require('../dist/compat/array/countBy.js').countBy;

export { flattenDepth as default } from '../dist/compat/array/flattenDepth.js';

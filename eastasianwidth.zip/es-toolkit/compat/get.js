module.exports = require('../dist/compat/object/get.js').get;

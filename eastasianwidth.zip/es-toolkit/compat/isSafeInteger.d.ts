export { isSafeInteger as default } from '../dist/compat/predicate/isSafeInteger.js';

export { isFinite as default } from '../dist/compat/predicate/isFinite.js';

module.exports = require('../dist/compat/string/deburr.js').deburr;

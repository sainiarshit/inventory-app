module.exports = require('../dist/compat/math/clamp.js').clamp;

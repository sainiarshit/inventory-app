export { isArray as default } from '../dist/compat/predicate/isArray.js';

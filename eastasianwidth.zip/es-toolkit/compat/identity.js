module.exports = require('../dist/function/identity.js').identity;

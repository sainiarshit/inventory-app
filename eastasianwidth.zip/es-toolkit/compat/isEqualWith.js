module.exports = require('../dist/compat/predicate/isEqualWith.js').isEqualWith;

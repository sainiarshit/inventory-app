module.exports = require('../dist/compat/array/forEachRight.js').forEachRight;

module.exports = require('../dist/compat/object/assignIn.js').assignIn;

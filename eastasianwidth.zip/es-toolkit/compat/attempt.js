module.exports = require('../dist/compat/function/attempt.js').attempt;

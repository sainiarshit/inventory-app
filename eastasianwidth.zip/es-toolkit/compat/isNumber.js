module.exports = require('../dist/compat/predicate/isNumber.js').isNumber;

export { invert as default } from '../dist/object/invert.js';

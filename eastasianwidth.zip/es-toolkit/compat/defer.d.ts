export { defer as default } from '../dist/compat/function/defer.js';

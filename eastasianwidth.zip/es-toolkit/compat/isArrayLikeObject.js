module.exports = require('../dist/compat/predicate/isArrayLikeObject.js').isArrayLikeObject;

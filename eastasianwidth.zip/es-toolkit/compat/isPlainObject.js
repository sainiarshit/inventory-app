module.exports = require('../dist/compat/predicate/isPlainObject.js').isPlainObject;

export { findLastIndex as default } from '../dist/compat/array/findLastIndex.js';

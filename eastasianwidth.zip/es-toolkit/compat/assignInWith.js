module.exports = require('../dist/compat/object/assignInWith.js').assignInWith;

export { bindKey as default } from '../dist/compat/function/bindKey.js';

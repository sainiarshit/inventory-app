export { chunk as default } from '../dist/compat/array/chunk.js';

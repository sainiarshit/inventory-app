module.exports = require('../dist/compat/function/ary.js').ary;

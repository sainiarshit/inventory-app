module.exports = require('../dist/compat/string/endsWith.js').endsWith;

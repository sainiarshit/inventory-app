export { invoke as default } from '../dist/compat/util/invoke.js';

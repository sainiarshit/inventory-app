module.exports = require('../dist/compat/object/fromPairs.js').fromPairs;

module.exports = require('../dist/compat/object/cloneWith.js').cloneWith;

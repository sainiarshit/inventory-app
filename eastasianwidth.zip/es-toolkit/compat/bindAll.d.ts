export { bindAll as default } from '../dist/compat/util/bindAll.js';

module.exports = require('../dist/compat/predicate/isArrayLike.js').isArrayLike;

export { create as default } from '../dist/compat/object/create.js';

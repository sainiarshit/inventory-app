module.exports = require('../dist/compat/predicate/isBuffer.js').isBuffer;

export { endsWith as default } from '../dist/compat/string/endsWith.js';

module.exports = require('../dist/compat/function/after.js').after;

export { cloneDeep as default } from '../dist/compat/object/cloneDeep.js';

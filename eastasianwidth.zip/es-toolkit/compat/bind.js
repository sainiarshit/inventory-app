module.exports = require('../dist/compat/function/bind.js').bind;

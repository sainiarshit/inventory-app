export { attempt as default } from '../dist/compat/function/attempt.js';

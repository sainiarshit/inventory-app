module.exports = require('../dist/compat/predicate/isFinite.js').isFinite;

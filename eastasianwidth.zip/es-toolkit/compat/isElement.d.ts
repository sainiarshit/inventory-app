export { isElement as default } from '../dist/compat/predicate/isElement.js';

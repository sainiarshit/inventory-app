export { isError as default } from '../dist/compat/predicate/isError.js';

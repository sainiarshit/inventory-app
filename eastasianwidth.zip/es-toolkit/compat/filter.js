module.exports = require('../dist/compat/array/filter.js').filter;

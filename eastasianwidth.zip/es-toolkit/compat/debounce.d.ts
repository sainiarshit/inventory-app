export { debounce as default } from '../dist/compat/function/debounce.js';

module.exports = require('../dist/compat/predicate/isArray.js').isArray;

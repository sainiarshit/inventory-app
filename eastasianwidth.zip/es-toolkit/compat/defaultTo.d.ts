export { defaultTo as default } from '../dist/compat/util/defaultTo.js';

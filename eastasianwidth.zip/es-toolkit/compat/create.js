module.exports = require('../dist/compat/object/create.js').create;

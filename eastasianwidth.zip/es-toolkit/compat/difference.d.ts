export { difference as default } from '../dist/compat/array/difference.js';

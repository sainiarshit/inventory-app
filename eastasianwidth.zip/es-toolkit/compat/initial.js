module.exports = require('../dist/compat/array/initial.js').initial;

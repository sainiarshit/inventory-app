module.exports = require('../dist/compat/predicate/isRegExp.js').isRegExp;

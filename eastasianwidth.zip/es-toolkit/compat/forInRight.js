module.exports = require('../dist/compat/object/forInRight.js').forInRight;

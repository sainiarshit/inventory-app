export { isEqual as default } from '../dist/predicate/isEqual.js';

export { bind as default } from '../dist/compat/function/bind.js';

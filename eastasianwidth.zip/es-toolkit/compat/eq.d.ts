export { eq as default } from '../dist/compat/util/eq.js';

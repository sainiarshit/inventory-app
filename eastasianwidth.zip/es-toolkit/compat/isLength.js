module.exports = require('../dist/predicate/isLength.js').isLength;

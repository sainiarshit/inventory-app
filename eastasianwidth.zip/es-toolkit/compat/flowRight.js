module.exports = require('../dist/compat/function/flowRight.js').flowRight;

module.exports = require('../dist/compat/util/eq.js').eq;

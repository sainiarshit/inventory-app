export { isRegExp as default } from '../dist/compat/predicate/isRegExp.js';

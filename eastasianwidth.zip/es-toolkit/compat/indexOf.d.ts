export { indexOf as default } from '../dist/compat/array/indexOf.js';

module.exports = require('../dist/compat/string/camelCase.js').camelCase;

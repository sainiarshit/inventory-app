export { forOwn as default } from '../dist/compat/object/forOwn.js';

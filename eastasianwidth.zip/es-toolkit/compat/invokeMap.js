module.exports = require('../dist/compat/array/invokeMap.js').invokeMap;

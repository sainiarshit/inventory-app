module.exports = require('../dist/compat/predicate/isEmpty.js').isEmpty;

export { isDate as default } from '../dist/compat/predicate/isDate.js';

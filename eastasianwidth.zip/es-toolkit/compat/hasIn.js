module.exports = require('../dist/compat/object/hasIn.js').hasIn;

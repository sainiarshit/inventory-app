module.exports = require('../dist/compat/object/assignWith.js').assignWith;

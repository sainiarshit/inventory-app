export { differenceBy as default } from '../dist/compat/array/differenceBy.js';

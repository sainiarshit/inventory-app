module.exports = require('../dist/string/capitalize.js').capitalize;

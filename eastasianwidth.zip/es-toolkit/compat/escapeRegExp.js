module.exports = require('../dist/compat/string/escapeRegExp.js').escapeRegExp;

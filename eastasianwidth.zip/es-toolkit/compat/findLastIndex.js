module.exports = require('../dist/compat/array/findLastIndex.js').findLastIndex;

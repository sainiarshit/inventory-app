module.exports = require('../dist/compat/math/inRange.js').inRange;

export { isPlainObject as default } from '../dist/compat/predicate/isPlainObject.js';

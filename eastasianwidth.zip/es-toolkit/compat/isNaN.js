module.exports = require('../dist/compat/predicate/isNaN.js').isNaN;

export { initial as default } from '../dist/compat/array/initial.js';

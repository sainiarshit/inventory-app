export { clone as default } from '../dist/compat/object/clone.js';

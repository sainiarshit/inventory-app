export { after as default } from '../dist/compat/function/after.js';

module.exports = require('../dist/compat/predicate/isObject.js').isObject;

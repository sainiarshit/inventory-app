export { countBy as default } from '../dist/compat/array/countBy.js';

module.exports = require('../dist/compat/function/curryRight.js').curryRight;

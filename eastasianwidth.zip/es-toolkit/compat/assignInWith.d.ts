export { assignInWith as default } from '../dist/compat/object/assignInWith.js';

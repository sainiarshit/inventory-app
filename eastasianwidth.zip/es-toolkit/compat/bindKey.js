module.exports = require('../dist/compat/function/bindKey.js').bindKey;

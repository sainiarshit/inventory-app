export { invertBy as default } from '../dist/compat/object/invertBy.js';

export { forEachRight as default } from '../dist/compat/array/forEachRight.js';

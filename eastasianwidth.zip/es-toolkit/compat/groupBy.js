module.exports = require('../dist/compat/array/groupBy.js').groupBy;

export { ceil as default } from '../dist/compat/math/ceil.js';

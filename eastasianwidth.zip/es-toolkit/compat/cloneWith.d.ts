export { cloneWith as default } from '../dist/compat/object/cloneWith.js';

export { assignWith as default } from '../dist/compat/object/assignWith.js';

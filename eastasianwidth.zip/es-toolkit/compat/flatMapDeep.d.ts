export { flatMapDeep as default } from '../dist/compat/array/flatMapDeep.js';

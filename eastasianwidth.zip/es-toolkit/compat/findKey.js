module.exports = require('../dist/compat/object/findKey.js').findKey;

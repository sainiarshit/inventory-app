export { concat as default } from '../dist/compat/array/concat.js';

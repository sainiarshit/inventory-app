export { castArray as default } from '../dist/compat/array/castArray.js';

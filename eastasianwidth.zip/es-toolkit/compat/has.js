module.exports = require('../dist/compat/object/has.js').has;

module.exports = require('../dist/compat/array/every.js').every;

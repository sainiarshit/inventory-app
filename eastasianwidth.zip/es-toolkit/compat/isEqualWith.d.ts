export { isEqualWith as default } from '../dist/compat/predicate/isEqualWith.js';

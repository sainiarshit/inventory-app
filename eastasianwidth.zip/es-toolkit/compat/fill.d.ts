export { fill as default } from '../dist/compat/array/fill.js';

export { deburr as default } from '../dist/compat/string/deburr.js';

export { flatMapDepth as default } from '../dist/compat/array/flatMapDepth.js';

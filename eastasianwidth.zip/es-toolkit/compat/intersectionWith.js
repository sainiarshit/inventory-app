module.exports = require('../dist/compat/array/intersectionWith.js').intersectionWith;

export { constant as default } from '../dist/compat/util/constant.js';

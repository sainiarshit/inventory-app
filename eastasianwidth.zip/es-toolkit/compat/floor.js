module.exports = require('../dist/compat/math/floor.js').floor;

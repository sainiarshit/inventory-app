export { flatten as default } from '../dist/compat/array/flatten.js';

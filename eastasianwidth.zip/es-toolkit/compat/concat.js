module.exports = require('../dist/compat/array/concat.js').concat;

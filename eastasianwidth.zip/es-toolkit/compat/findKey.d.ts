export { findKey as default } from '../dist/compat/object/findKey.js';

export { isNative as default } from '../dist/compat/predicate/isNative.js';

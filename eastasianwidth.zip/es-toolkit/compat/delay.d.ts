export { delay as default } from '../dist/compat/function/delay.js';

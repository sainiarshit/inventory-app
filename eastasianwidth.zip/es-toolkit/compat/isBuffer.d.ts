export { isBuffer as default } from '../dist/compat/predicate/isBuffer.js';

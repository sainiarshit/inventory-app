export { intersectionWith as default } from '../dist/compat/array/intersectionWith.js';

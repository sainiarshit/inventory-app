module.exports = require('../dist/compat/array/intersection.js').intersection;

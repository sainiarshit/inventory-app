export { camelCase as default } from '../dist/compat/string/camelCase.js';

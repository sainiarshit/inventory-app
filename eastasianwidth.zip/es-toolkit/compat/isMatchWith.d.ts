export { isMatchWith as default } from '../dist/compat/predicate/isMatchWith.js';

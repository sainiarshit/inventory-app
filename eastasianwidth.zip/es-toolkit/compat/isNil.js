module.exports = require('../dist/compat/predicate/isNil.js').isNil;

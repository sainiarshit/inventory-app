module.exports = require('../dist/compat/util/constant.js').constant;

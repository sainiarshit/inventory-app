export { defaults as default } from '../dist/compat/object/defaults.js';

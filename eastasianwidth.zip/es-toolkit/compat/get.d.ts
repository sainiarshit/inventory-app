export { get as default } from '../dist/compat/object/get.js';

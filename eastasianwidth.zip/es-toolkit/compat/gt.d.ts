export { gt as default } from '../dist/compat/util/gt.js';

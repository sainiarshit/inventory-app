export { inRange as default } from '../dist/compat/math/inRange.js';

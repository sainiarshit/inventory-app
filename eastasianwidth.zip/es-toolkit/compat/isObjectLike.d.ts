export { isObjectLike as default } from '../dist/compat/predicate/isObjectLike.js';

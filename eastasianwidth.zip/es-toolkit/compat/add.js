module.exports = require('../dist/compat/math/add.js').add;

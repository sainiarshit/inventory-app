module.exports = require('../dist/compat/object/cloneDeep.js').cloneDeep;

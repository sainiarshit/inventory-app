module.exports = require('../dist/compat/array/dropRightWhile.js').dropRightWhile;

export { forEach as default } from '../dist/compat/array/forEach.js';

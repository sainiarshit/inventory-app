export { compact as default } from '../dist/compat/array/compact.js';

module.exports = require('../dist/compat/function/delay.js').delay;

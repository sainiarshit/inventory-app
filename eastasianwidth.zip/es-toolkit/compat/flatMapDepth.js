module.exports = require('../dist/compat/array/flatMapDepth.js').flatMapDepth;

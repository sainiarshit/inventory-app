module.exports = require('../dist/compat/util/bindAll.js').bindAll;

export { isNumber as default } from '../dist/compat/predicate/isNumber.js';

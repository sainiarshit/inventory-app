module.exports = require('../dist/predicate/isFunction.js').isFunction;

export { gte as default } from '../dist/compat/util/gte.js';

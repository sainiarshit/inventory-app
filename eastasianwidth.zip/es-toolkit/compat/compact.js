module.exports = require('../dist/compat/array/compact.js').compact;

module.exports = require('../dist/compat/array/indexOf.js').indexOf;

module.exports = require('../dist/compat/array/fill.js').fill;

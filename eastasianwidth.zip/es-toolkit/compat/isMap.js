module.exports = require('../dist/compat/predicate/isMap.js').isMap;

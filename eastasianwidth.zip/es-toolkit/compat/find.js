module.exports = require('../dist/compat/array/find.js').find;

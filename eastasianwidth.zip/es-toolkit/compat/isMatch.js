module.exports = require('../dist/compat/predicate/isMatch.js').isMatch;

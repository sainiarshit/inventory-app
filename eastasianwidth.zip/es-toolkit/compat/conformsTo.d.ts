export { conformsTo as default } from '../dist/compat/predicate/conformsTo.js';

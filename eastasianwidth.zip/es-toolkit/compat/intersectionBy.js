module.exports = require('../dist/compat/array/intersectionBy.js').intersectionBy;

export { differenceWith as default } from '../dist/compat/array/differenceWith.js';

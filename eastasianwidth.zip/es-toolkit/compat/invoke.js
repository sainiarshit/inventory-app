module.exports = require('../dist/compat/util/invoke.js').invoke;

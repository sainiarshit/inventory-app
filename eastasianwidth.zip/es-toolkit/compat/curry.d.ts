export { curry as default } from '../dist/compat/function/curry.js';

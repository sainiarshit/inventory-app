export { drop as default } from '../dist/compat/array/drop.js';

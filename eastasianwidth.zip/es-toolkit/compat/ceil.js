module.exports = require('../dist/compat/math/ceil.js').ceil;

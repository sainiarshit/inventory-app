export { isArrayLikeObject as default } from '../dist/compat/predicate/isArrayLikeObject.js';

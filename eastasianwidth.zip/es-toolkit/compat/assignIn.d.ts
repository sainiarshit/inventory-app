export { assignIn as default } from '../dist/compat/object/assignIn.js';

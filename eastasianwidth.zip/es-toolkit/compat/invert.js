module.exports = require('../dist/object/invert.js').invert;

export { hasIn as default } from '../dist/compat/object/hasIn.js';

module.exports = require('../dist/compat/predicate/isError.js').isError;

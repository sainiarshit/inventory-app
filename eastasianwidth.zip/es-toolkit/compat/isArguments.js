module.exports = require('../dist/compat/predicate/isArguments.js').isArguments;

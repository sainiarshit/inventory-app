module.exports = require('../dist/compat/string/escape.js').escape;

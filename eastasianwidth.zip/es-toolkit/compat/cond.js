module.exports = require('../dist/compat/util/cond.js').cond;

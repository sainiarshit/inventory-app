module.exports = require('../dist/compat/predicate/conformsTo.js').conformsTo;

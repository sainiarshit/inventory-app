export { isFunction as default } from '../dist/predicate/isFunction.js';

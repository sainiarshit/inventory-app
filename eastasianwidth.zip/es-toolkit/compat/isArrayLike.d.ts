export { isArrayLike as default } from '../dist/compat/predicate/isArrayLike.js';

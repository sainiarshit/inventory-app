module.exports = require('../dist/compat/array/findIndex.js').findIndex;

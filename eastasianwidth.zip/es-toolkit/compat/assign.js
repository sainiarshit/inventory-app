module.exports = require('../dist/compat/object/assign.js').assign;

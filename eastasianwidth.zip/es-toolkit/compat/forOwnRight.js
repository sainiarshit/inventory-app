module.exports = require('../dist/compat/object/forOwnRight.js').forOwnRight;

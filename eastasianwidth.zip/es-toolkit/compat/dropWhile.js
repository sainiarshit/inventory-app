module.exports = require('../dist/compat/array/dropWhile.js').dropWhile;

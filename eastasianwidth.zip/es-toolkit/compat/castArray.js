module.exports = require('../dist/compat/array/castArray.js').castArray;

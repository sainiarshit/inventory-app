module.exports = require('../dist/compat/object/at.js').at;

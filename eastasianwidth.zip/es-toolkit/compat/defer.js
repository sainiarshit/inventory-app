module.exports = require('../dist/compat/function/defer.js').defer;

export { fromPairs as default } from '../dist/compat/object/fromPairs.js';

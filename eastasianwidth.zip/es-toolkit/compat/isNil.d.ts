export { isNil as default } from '../dist/compat/predicate/isNil.js';

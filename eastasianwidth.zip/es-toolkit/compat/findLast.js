module.exports = require('../dist/compat/array/findLast.js').findLast;

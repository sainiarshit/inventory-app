export { flowRight as default } from '../dist/compat/function/flowRight.js';

module.exports = require('../dist/compat/predicate/isDate.js').isDate;

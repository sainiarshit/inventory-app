module.exports = require('../dist/compat/array/flatten.js').flatten;

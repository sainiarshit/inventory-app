export { filter as default } from '../dist/compat/array/filter.js';

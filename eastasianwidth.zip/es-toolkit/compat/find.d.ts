export { find as default } from '../dist/compat/array/find.js';

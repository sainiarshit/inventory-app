module.exports = require('../dist/compat/util/gt.js').gt;

module.exports = require('../dist/compat/object/functions.js').functions;

export { isMap as default } from '../dist/compat/predicate/isMap.js';

module.exports = require('../dist/compat/object/invertBy.js').invertBy;

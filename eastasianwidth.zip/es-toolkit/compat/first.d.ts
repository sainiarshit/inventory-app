export { head as default } from '../dist/compat/array/head.js';

module.exports = require('../dist/compat/array/differenceWith.js').differenceWith;

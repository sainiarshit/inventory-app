export { defaultsDeep as default } from '../dist/compat/object/defaultsDeep.js';

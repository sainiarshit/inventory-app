export { escape as default } from '../dist/compat/string/escape.js';

export { flow as default } from '../dist/compat/function/flow.js';

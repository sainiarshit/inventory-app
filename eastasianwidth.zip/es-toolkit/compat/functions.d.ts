export { functions as default } from '../dist/compat/object/functions.js';

export { assign as default } from '../dist/compat/object/assign.js';

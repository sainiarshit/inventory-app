export { dropWhile as default } from '../dist/compat/array/dropWhile.js';

module.exports = require('../dist/compat/object/clone.js').clone;

export { flatMap as default } from '../dist/compat/array/flatMap.js';

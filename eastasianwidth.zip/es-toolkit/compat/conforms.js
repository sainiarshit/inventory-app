module.exports = require('../dist/compat/predicate/conforms.js').conforms;

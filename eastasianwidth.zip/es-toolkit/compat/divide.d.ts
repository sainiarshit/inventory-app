export { divide as default } from '../dist/compat/math/divide.js';

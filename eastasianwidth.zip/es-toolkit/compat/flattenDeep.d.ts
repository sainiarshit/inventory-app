export { flattenDeep as default } from '../dist/compat/array/flattenDeep.js';

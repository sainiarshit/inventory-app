module.exports = require('../dist/compat/predicate/isNative.js').isNative;

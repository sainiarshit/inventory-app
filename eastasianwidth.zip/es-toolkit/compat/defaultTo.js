module.exports = require('../dist/compat/util/defaultTo.js').defaultTo;

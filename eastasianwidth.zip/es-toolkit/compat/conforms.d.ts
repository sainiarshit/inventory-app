export { conforms as default } from '../dist/compat/predicate/conforms.js';

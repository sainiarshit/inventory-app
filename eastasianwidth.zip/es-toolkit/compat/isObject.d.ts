export { isObject as default } from '../dist/compat/predicate/isObject.js';

export { isNull as default } from '../dist/predicate/isNull.js';

export { cond as default } from '../dist/compat/util/cond.js';

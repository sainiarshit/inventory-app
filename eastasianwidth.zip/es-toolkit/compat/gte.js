module.exports = require('../dist/compat/util/gte.js').gte;

module.exports = require('../dist/compat/array/includes.js').includes;

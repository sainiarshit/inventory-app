module.exports = require('../dist/compat/object/findLastKey.js').findLastKey;

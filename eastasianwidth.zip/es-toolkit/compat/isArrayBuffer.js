module.exports = require('../dist/compat/predicate/isArrayBuffer.js').isArrayBuffer;

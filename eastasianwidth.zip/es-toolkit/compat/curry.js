module.exports = require('../dist/compat/function/curry.js').curry;

module.exports = require('../dist/compat/object/forOwn.js').forOwn;

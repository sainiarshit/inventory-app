export { forIn as default } from '../dist/compat/object/forIn.js';

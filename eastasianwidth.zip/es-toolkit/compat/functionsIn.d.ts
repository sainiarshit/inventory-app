export { functionsIn as default } from '../dist/compat/object/functionsIn.js';

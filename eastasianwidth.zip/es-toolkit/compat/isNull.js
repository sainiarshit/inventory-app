module.exports = require('../dist/predicate/isNull.js').isNull;

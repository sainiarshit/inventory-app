module.exports = require('../dist/compat/array/drop.js').drop;

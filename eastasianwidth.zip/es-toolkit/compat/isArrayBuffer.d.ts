export { isArrayBuffer as default } from '../dist/compat/predicate/isArrayBuffer.js';

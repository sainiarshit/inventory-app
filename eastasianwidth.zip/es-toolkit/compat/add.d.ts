export { add as default } from '../dist/compat/math/add.js';

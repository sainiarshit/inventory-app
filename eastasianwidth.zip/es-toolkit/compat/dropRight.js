module.exports = require('../dist/compat/array/dropRight.js').dropRight;

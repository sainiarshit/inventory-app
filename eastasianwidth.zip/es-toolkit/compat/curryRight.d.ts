export { curryRight as default } from '../dist/compat/function/curryRight.js';

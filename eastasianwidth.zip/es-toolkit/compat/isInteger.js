module.exports = require('../dist/compat/predicate/isInteger.js').isInteger;

export { clamp as default } from '../dist/compat/math/clamp.js';

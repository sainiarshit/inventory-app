export { invokeMap as default } from '../dist/compat/array/invokeMap.js';

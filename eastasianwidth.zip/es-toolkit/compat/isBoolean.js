module.exports = require('../dist/compat/predicate/isBoolean.js').isBoolean;

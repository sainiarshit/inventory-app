export { isLength as default } from '../dist/predicate/isLength.js';

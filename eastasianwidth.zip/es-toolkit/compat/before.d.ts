export { before as default } from '../dist/compat/function/before.js';

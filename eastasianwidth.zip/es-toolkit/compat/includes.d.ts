export { includes as default } from '../dist/compat/array/includes.js';

module.exports = require('../dist/compat/array/differenceBy.js').differenceBy;

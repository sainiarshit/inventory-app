module.exports = require('../dist/compat/function/debounce.js').debounce;

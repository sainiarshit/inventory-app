export { identity as default } from '../dist/function/identity.js';

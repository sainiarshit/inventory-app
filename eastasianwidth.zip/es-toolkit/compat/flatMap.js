module.exports = require('../dist/compat/array/flatMap.js').flatMap;

module.exports = require('../dist/compat/object/functionsIn.js').functionsIn;

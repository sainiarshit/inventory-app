module.exports = require('../dist/compat/object/forIn.js').forIn;

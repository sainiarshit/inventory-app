export { at as default } from '../dist/compat/object/at.js';

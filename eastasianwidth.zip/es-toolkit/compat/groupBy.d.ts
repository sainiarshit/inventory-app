export { groupBy as default } from '../dist/compat/array/groupBy.js';

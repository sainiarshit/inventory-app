export { cloneDeepWith as default } from '../dist/compat/object/cloneDeepWith.js';

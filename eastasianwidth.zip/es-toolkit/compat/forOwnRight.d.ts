export { forOwnRight as default } from '../dist/compat/object/forOwnRight.js';

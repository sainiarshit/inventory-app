export { isInteger as default } from '../dist/compat/predicate/isInteger.js';

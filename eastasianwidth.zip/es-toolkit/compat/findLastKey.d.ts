export { findLastKey as default } from '../dist/compat/object/findLastKey.js';

module.exports = require('../dist/compat/function/before.js').before;

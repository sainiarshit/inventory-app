export { escapeRegExp as default } from '../dist/compat/string/escapeRegExp.js';

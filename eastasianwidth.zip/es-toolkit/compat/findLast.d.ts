export { findLast as default } from '../dist/compat/array/findLast.js';

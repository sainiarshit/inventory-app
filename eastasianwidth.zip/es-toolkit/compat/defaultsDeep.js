module.exports = require('../dist/compat/object/defaultsDeep.js').defaultsDeep;

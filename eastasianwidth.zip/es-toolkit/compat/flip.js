module.exports = require('../dist/compat/function/flip.js').flip;

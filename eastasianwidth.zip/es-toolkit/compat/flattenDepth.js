module.exports = require('../dist/compat/array/flattenDepth.js').flattenDepth;

export { has as default } from '../dist/compat/object/has.js';

export { every as default } from '../dist/compat/array/every.js';

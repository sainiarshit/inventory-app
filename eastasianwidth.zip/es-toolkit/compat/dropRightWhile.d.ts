export { dropRightWhile as default } from '../dist/compat/array/dropRightWhile.js';

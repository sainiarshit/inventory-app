export { isMatch as default } from '../dist/compat/predicate/isMatch.js';

module.exports = require('../dist/compat/predicate/isMatchWith.js').isMatchWith;

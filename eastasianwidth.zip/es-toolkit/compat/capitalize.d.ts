export { capitalize as default } from '../dist/string/capitalize.js';

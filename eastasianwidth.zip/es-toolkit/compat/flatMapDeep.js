module.exports = require('../dist/compat/array/flatMapDeep.js').flatMapDeep;

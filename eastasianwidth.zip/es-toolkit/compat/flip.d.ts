export { flip as default } from '../dist/compat/function/flip.js';

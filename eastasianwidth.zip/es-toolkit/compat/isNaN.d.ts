export { isNaN as default } from '../dist/compat/predicate/isNaN.js';

export { forInRight as default } from '../dist/compat/object/forInRight.js';

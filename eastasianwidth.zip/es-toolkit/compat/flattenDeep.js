module.exports = require('../dist/compat/array/flattenDeep.js').flattenDeep;

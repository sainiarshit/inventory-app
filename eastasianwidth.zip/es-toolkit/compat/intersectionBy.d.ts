export { intersectionBy as default } from '../dist/compat/array/intersectionBy.js';

export { isBoolean as default } from '../dist/compat/predicate/isBoolean.js';

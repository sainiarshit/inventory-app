module.exports = require('../dist/compat/array/chunk.js').chunk;

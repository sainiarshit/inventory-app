export { isEmpty as default } from '../dist/compat/predicate/isEmpty.js';

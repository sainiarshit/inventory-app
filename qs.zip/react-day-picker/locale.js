/* eslint-disable @typescript-eslint/no-require-imports */
/* eslint-disable no-undef */
const locale = require("./dist/cjs/locale.js");
module.exports = locale;

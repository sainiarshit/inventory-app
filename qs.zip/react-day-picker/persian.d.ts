export * from "./dist/cjs/persian.d.ts";

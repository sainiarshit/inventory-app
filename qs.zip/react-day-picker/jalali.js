/* eslint-disable @typescript-eslint/no-require-imports */
/* eslint-disable no-undef */
const jalali = require("./dist/cjs/jalali.js");
module.exports = jalali;

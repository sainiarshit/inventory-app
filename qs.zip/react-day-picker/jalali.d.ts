export * from "./dist/cjs/jalali.d.ts";

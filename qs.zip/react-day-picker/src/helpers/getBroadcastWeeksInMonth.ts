import { DateLib } from "../classes/index.js";

const FIVE_WEEKS = 5;
const FOUR_WEEKS = 4;

/**
 * Returns the number of weeks to display in the broadcast calendar for a given
 * month.
 *
 * The broadcast calendar may have either 4 or 5 weeks in a month, depending on
 * the start and end dates of the broadcast weeks.
 *
 * @since 9.4.0
 * @param month The month for which to calculate the number of weeks.
 * @param dateLib The date library to use for date manipulation.
 * @returns The number of weeks in the broadcast calendar (4 or 5).
 */
export function getBroadcastWeeksInMonth(month: Date, dateLib: DateLib): 4 | 5 {
  // Get the first day of the month
  const firstDayOfMonth = dateLib.startOfMonth(month);

  // Get the day of the week for the first day of the month (1-7, where 1 is Monday)
  const firstDayOfWeek =
    firstDayOfMonth.getDay() > 0 ? firstDayOfMonth.getDay() : 7;

  const broadcastStartDate = dateLib.addDays(month, -firstDayOfWeek + 1);

  const lastDateOfLastWeek = dateLib.addDays(
    broadcastStartDate,
    FIVE_WEEKS * 7 - 1
  );
  const numberOfWeeks =
    dateLib.getMonth(month) === dateLib.getMonth(lastDateOfLastWeek)
      ? FIVE_WEEKS
      : FOUR_WEEKS;

  return numberOfWeeks;
}

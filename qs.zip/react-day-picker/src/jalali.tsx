/** @deprecated Import from `react-day-picker/persian` instead. */
export * from "./persian.js";

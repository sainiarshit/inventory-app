import { labelNav } from "./labelNav";

test("should return the label", () => {
  expect(labelNav()).toEqual("");
});

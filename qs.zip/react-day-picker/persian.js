/* eslint-disable @typescript-eslint/no-require-imports */
/* eslint-disable no-undef */
const persian = require("./dist/cjs/persian.js");
module.exports = persian;

import * as React from 'react';
import { SetPolarGraphicalItem } from '../state/SetGraphicalItem';
export var PolarGraphicalItemContext = props => {
  return /*#__PURE__*/React.createElement(SetPolarGraphicalItem, props);
};
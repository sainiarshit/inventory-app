export function selectSynchronisedTooltipState(state) {
  return state.tooltip.syncInteraction;
}
export var selectChartWidth = state => state.layout.width;
export var selectChartHeight = state => state.layout.height;
export var selectContainerScale = state => state.layout.scale;
export var selectMargin = state => state.layout.margin;
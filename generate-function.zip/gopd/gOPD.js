'use strict';

/** @type {import('./gOPD')} */
module.exports = Object.getOwnPropertyDescriptor;

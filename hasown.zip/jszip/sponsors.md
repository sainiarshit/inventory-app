---
title: "Sponsors"
layout: default
section: main
---

[JSZip](https://github.com/Stuk/jszip) was created in 2009 by [Stuart](https://github.com/Stuk). Since then it has received well over [600 million downloads](https://npm-stat.com/charts.html?package=jszip&from=2009-06-20&to=2022-06-20), is depended on by over 3000 packages on npm, and powers zipping and unzipping on sites large and small.

This project only exists because of all the work dedicated to it by me and the other contributors.

If you or your company has benefited from JSZip then please consider [sponsoring on Github](https://github.com/sponsors/Stuk).

## 💎 Diamond

## 🥇 Gold

## 🥈 Silver

## 🥉 Bronze

## Supporters

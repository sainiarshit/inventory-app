import { getNativeWebSocket } from "./utils.js";
export const WebSocket = getNativeWebSocket();
//# sourceMappingURL=native.js.map
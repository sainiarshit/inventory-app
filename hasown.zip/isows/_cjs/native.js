"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.WebSocket = void 0;
const utils_js_1 = require("./utils.js");
exports.WebSocket = (0, utils_js_1.getNativeWebSocket)();
//# sourceMappingURL=native.js.map
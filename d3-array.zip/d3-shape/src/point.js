export function x(p) {
  return p[0];
}

export function y(p) {
  return p[1];
}

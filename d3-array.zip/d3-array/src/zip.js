import transpose from "./transpose.js";

export default function zip() {
  return transpose(arguments);
}

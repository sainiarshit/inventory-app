export const linear = t => +t;

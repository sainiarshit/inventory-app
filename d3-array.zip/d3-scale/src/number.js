export default function number(x) {
  return +x;
}

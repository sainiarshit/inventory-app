export default function constants(x) {
  return function() {
    return x;
  };
}

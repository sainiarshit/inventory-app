export default function(x) {
  return x;
}
